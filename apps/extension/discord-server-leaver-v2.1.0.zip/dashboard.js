"use strict";
(() => {
  // src/api.ts
  var DEFAULT_ORIGIN = "https://discord-server-leaver-production.up.railway.app".replace(/\/$/, "");
  async function apiOrigin() {
    const result = await chrome.storage.local.get("apiOrigin");
    return String(result.apiOrigin || DEFAULT_ORIGIN).replace(/\/$/, "");
  }
  async function authToken() {
    const result = await chrome.storage.local.get("sessionToken");
    return typeof result.sessionToken === "string" ? result.sessionToken : void 0;
  }
  async function api(path, init = {}) {
    const origin = await apiOrigin();
    const headers = new Headers(init.headers);
    const token = await authToken();
    if (token) headers.set("Authorization", `Bearer ${token}`);
    if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    const response = await fetch(`${origin}${path}`, { ...init, headers, credentials: "include" });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new ApiError(response.status, body.error || `Request failed (${response.status})`, body);
    return body;
  }
  var ApiError = class extends Error {
    constructor(status, message, detail) {
      super(message);
      this.status = status;
      this.detail = detail;
    }
  };
  async function exchangeLoginCode(code) {
    const result = await api("/auth/exchange", { method: "POST", body: JSON.stringify({ code }) });
    await chrome.storage.local.set({ sessionToken: result.token });
  }
  async function currentUser() {
    return api("/auth/me");
  }
  async function listGuilds() {
    return api("/guilds");
  }
  async function leaveOneGuild(guild) {
    return api(`/guilds/${encodeURIComponent(guild.id)}/leave`, { method: "POST", body: JSON.stringify({ confirm: true, guildName: guild.name }) });
  }
  async function listMemories() {
    return api("/memories");
  }
  async function createMemory(data) {
    return api("/memories", { method: "POST", body: JSON.stringify(data) });
  }
  async function createDonation(amount, email) {
    return api("/api/donate", { method: "POST", body: JSON.stringify({ amount, email }) });
  }
  async function deleteCloudData() {
    return api("/data/all", { method: "DELETE" });
  }
  async function logout() {
    try {
      await api("/auth/logout", { method: "POST" });
    } finally {
      await chrome.storage.local.remove("sessionToken");
    }
  }

  // src/dashboard.ts
  var view = "overview";
  var user;
  var guilds = [];
  var memories = [];
  var notice = "";
  var app = document.querySelector("#app");
  var esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char] || char);
  var errorText = (error) => error instanceof ApiError || error instanceof Error ? error.message : "Unexpected error";
  function dashboardDialog(options) {
    document.querySelector("#dashboard-dialog")?.remove();
    const wrapper = document.createElement("div");
    wrapper.id = "dashboard-dialog";
    wrapper.className = "dashboard-dialog-backdrop";
    wrapper.innerHTML = '<section class="dashboard-dialog" role="dialog" aria-modal="true"><div class="dashboard-dialog-icon">!</div><h2>' + esc(options.title) + "</h2><p>" + esc(options.message) + "</p>" + (options.requiredText ? "<label>Type " + esc(options.requiredText) + ' to continue<input id="dashboard-dialog-input" autocomplete="off"></label>' : "") + '<div class="dashboard-dialog-actions"><button class="btn ghost" data-dialog-cancel>Cancel</button><button class="btn ' + (options.danger ? "danger" : "primary") + '" data-dialog-confirm' + (options.requiredText ? " disabled" : "") + ">" + esc(options.confirmLabel || "Confirm") + "</button></div></section>";
    document.body.appendChild(wrapper);
    const input = wrapper.querySelector("#dashboard-dialog-input");
    const confirmButton = wrapper.querySelector("[data-dialog-confirm]");
    return new Promise((resolve) => {
      const close = (value) => {
        wrapper.remove();
        resolve(value);
      };
      input?.addEventListener("input", () => {
        confirmButton.disabled = input.value !== options.requiredText;
      });
      wrapper.querySelector("[data-dialog-cancel]")?.addEventListener("click", () => close(false));
      confirmButton.addEventListener("click", () => close(true));
      wrapper.addEventListener("click", (event) => {
        if (event.target === wrapper) close(false);
      });
      window.setTimeout(() => (input || wrapper.querySelector("[data-dialog-cancel]"))?.focus(), 0);
    });
  }
  async function boot() {
    const code = new URLSearchParams(location.search).get("code");
    if (code) {
      try {
        await exchangeLoginCode(code);
        history.replaceState({}, "", location.pathname);
      } catch (error) {
        notice = errorText(error);
      }
    }
    try {
      user = (await currentUser()).user;
      await refresh();
    } catch {
      user = void 0;
    }
    render();
  }
  async function refresh() {
    if (!user) return;
    try {
      guilds = (await listGuilds()).guilds;
    } catch (error) {
      notice = errorText(error);
    }
    try {
      memories = (await listMemories()).memories;
    } catch {
    }
  }
  function nav(key, label) {
    return '<button class="' + (view === key ? "active" : "") + '" data-view="' + key + '">' + label + "</button>";
  }
  function pageTitle() {
    return { overview: "Your Discord workspace", servers: "Manage servers", memory: "AI Memory", donate: "Support development", settings: "Privacy & Settings" }[view];
  }
  function render() {
    const content = view === "overview" ? overview() : view === "servers" ? servers() : view === "memory" ? memoryPage() : view === "donate" ? donationPage() : settingsPage();
    app.innerHTML = '<div class="shell"><aside class="side"><div class="brand">Discord Server Leaver</div><p class="tagline">Focused tools for managing your Discord servers.</p><nav class="nav">' + nav("overview", "Overview") + nav("servers", "Servers") + nav("memory", "AI Memory") + nav("donate", "Support") + nav("settings", "Privacy & Settings") + '</nav><div class="side-footer">Your data stays local until you explicitly import it to cloud storage.</div></aside><main class="content"><div class="top"><div><div class="eyebrow">Discord Server Leaver \xB7 V2</div><h1 class="title">' + pageTitle() + '</h1><p class="sub">' + (user ? "Signed in as " + esc(user.username) : "Connect Discord when you are ready.") + '</p></div><div class="actions">' + (user ? '<span class="pill">' + user.freeQuestionsRemaining + " free AI \xB7 " + user.aiCredits + ' credits</span><button class="btn ghost" data-action="logout">Sign out</button>' : '<button class="btn primary" data-action="login">Connect Discord</button>') + "</div></div>" + (notice ? '<div class="notice">' + esc(notice) + ' <button class="btn ghost" data-action="dismiss">Dismiss</button></div>' : "") + content + "</main></div>";
    wire();
  }
  function overview() {
    return '<div class="grid"><div class="stat"><div class="label">Servers</div><div class="value">' + (guilds.length || "\u2014") + '</div></div><div class="stat"><div class="label">AI credits</div><div class="value">' + (user?.aiCredits || 0) + '</div></div><div class="stat"><div class="label">Memories</div><div class="value">' + memories.length + '</div></div></div><section class="card"><h2>Start here</h2><p>Connect Discord to manage servers, or open AI Memory to save the context that matters.</p><div class="toolbar"><button class="btn primary" data-view="servers">Manage servers</button><button class="btn" data-view="donate">Support development</button></div></section>';
  }
  function servers() {
    return '<section class="card"><div class="row"><div><h2>Bulk leave</h2><p>Select servers to leave. Owned servers are protected.</p></div><button class="btn danger" data-action="leave">Leave selected</button></div><div class="toolbar"><input class="input" id="guild-filter" placeholder="Search servers"><button class="btn ghost" data-action="refresh">Refresh</button></div><div class="table-wrap"><table class="table"><thead><tr><th></th><th>Server</th><th>Members</th><th>Status</th></tr></thead><tbody>' + (guilds.length ? guilds.map((guild) => '<tr><td><input type="checkbox" data-guild="' + esc(guild.id) + '" ' + (guild.owner ? "disabled" : "") + '></td><td><div class="server-cell">' + guildIcon(guild) + "<span>" + esc(guild.name) + "</span></div></td><td>" + (guild.approximate_member_count ?? "\u2014") + "</td><td>" + (guild.owner ? '<span class="pill">Owner</span>' : '<span class="pill">Leaveable</span>') + "</td></tr>").join("") : '<tr><td colspan="4">Connect Discord and refresh to load servers.</td></tr>') + "</tbody></table></div></section>";
  }
  function guildIcon(guild) {
    if (guild.icon) {
      const iconUrl = "https://cdn.discordapp.com/icons/" + esc(guild.id) + "/" + esc(guild.icon) + (guild.icon.startsWith("a_") ? ".gif" : ".png") + "?size=64";
      return '<img class="guild-icon" src="' + iconUrl + '" alt="">';
    }
    return '<div class="guild-icon-placeholder"></div>';
  }
  function memoryPage() {
    return '<section class="card"><h2>Saved memories</h2><form id="memory-form" class="form-grid"><div class="field"><label>Title</label><input class="input" name="title" required></div><div class="field"><label>Tags</label><input class="input" name="tags"></div><div class="field full"><label>Memory</label><textarea name="content" required></textarea></div><button class="btn primary">Save memory</button></form></section><section class="card">' + (memories.length ? memories.map((memory) => '<div class="card"><strong>' + esc(memory.title) + "</strong><p>" + esc(memory.content) + "</p></div>").join("") : '<div class="empty">No saved memories yet.</div>') + "</section>";
  }
  function donationPage() {
    return '<section class="card donation-panel"><div class="eyebrow">Support the project</div><h2>Keep Discord Server Leaver maintained.</h2><p>Choose a preset or enter a custom amount. Stripe securely handles payment details.</p><div class="form-grid"><div class="field"><label>Amount (USD)</label><div class="donation-input-wrapper"><span class="currency-symbol">$</span><input class="input donation-input" id="custom-amount" type="number" min="5" max="500" step="0.01" placeholder="10.00" required></div></div><div class="field"><label>Receipt email</label><input class="input" id="donation-email" type="email" placeholder="you@example.com" required></div></div><div class="quick-amounts"><button class="btn" type="button" data-action="donate-5">$5</button><button class="btn" type="button" data-action="donate-10">$10</button><button class="btn" type="button" data-action="donate-25">$25</button><button class="btn" type="button" data-action="donate-50">$50</button></div><button class="btn primary full-width" data-action="donate-custom">Continue to secure checkout</button><p class="donation-footnote">Your card information is sent directly to Stripe.</p></section>';
  }
  function settingsPage() {
    return '<section class="card"><h2>Privacy & data</h2><p>Account data is scoped to your Discord identity. Local browser data is never uploaded automatically.</p><button class="btn danger" data-action="delete-cloud">Delete cloud data</button></section>';
  }
  function wire() {
    document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => {
      view = button.dataset.view;
      notice = "";
      render();
    }));
    document.querySelector("[data-action=dismiss]")?.addEventListener("click", () => {
      notice = "";
      render();
    });
    document.querySelector("[data-action=login]")?.addEventListener("click", () => void login());
    document.querySelector("[data-action=logout]")?.addEventListener("click", () => void doLogout());
    document.querySelector("[data-action=refresh]")?.addEventListener("click", () => void refreshPage());
    document.querySelector("[data-action=leave]")?.addEventListener("click", () => void leaveSelected());
    document.querySelector("[data-action=delete-cloud]")?.addEventListener("click", () => void deleteCloud());
    document.querySelector("[data-action=donate-custom]")?.addEventListener("click", () => void donateCustom());
    for (const amount of [5, 10, 25, 50]) document.querySelector("[data-action=donate-" + amount + "]")?.addEventListener("click", () => {
      const input = document.querySelector("#custom-amount");
      if (input) input.value = String(amount);
    });
    document.querySelector("#memory-form")?.addEventListener("submit", (event) => void saveMemory(event));
  }
  async function login() {
    try {
      const origin = await apiOrigin();
      const redirect = chrome.identity.getRedirectURL();
      const result = await chrome.identity.launchWebAuthFlow({ url: origin + "/auth/discord/start?return_to=" + encodeURIComponent(redirect), interactive: true });
      if (!result) throw new Error("Discord login did not complete");
      const code = new URL(result).searchParams.get("code");
      if (!code) throw new Error("Discord login did not complete");
      await exchangeLoginCode(code);
      user = (await currentUser()).user;
      await refresh();
      render();
    } catch (error) {
      notice = "Error: " + errorText(error);
      render();
    }
  }
  async function doLogout() {
    await logout();
    user = void 0;
    guilds = [];
    memories = [];
    render();
  }
  async function refreshPage() {
    await refresh();
    render();
  }
  async function leaveSelected() {
    const selected = Array.from(document.querySelectorAll("[data-guild]:checked")).map((input) => guilds.find((guild) => guild.id === input.dataset.guild)).filter((guild) => Boolean(guild && !guild.owner));
    if (!selected.length) {
      notice = "Select at least one leaveable server.";
      render();
      return;
    }
    if (!await dashboardDialog({ title: "Leave selected servers?", message: "You are about to leave " + selected.length + " server(s). This cannot be undone.", confirmLabel: "Leave servers", danger: true })) return;
    for (const guild of selected) {
      try {
        await leaveOneGuild(guild);
      } catch (error) {
        notice = "Error leaving " + guild.name + ": " + errorText(error);
      }
    }
    await refresh();
    render();
  }
  async function saveMemory(event) {
    event.preventDefault();
    const data = new FormData(event.target);
    try {
      await createMemory({ title: data.get("title"), content: data.get("content"), tags: String(data.get("tags") || "").split(",").map((tag) => tag.trim()).filter(Boolean) });
      memories = (await listMemories()).memories;
      render();
    } catch (error) {
      notice = "Error: " + errorText(error);
      render();
    }
  }
  async function deleteCloud() {
    if (await dashboardDialog({ title: "Delete cloud data?", message: "Saved memories will be removed from your account.", confirmLabel: "Delete cloud data", requiredText: "DELETE", danger: true })) {
      await deleteCloudData();
      memories = [];
      notice = "Cloud data deleted.";
      render();
    }
  }
  async function donateCustom() {
    const input = document.querySelector("#custom-amount");
    const emailInput = document.querySelector("#donation-email");
    const amount = Number(input?.value || 0);
    const email = emailInput?.value.trim() || "";
    if (!Number.isFinite(amount) || amount < 5 || amount > 500 || !emailInput?.validity.valid) {
      notice = "Enter a valid amount ($5-$500) and receipt email.";
      render();
      return;
    }
    try {
      const result = await createDonation(Math.round(amount * 100) / 100, email);
      await chrome.tabs.create({ url: result.url });
      notice = "Secure checkout opened in a new tab.";
    } catch (error) {
      notice = "Error: " + errorText(error);
      render();
    }
  }
  boot().catch((error) => {
    notice = "Error: " + errorText(error);
    render();
  });
})();
//# sourceMappingURL=dashboard.js.map
